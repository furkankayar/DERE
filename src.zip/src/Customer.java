
public class Customer extends Person{

  private int id;
  private boolean active;
  private static int autoincrement = 1;

  public Customer(String name, Date birthdate, Address address, Phone phone, String gender ){

    super(name, birthdate, address, phone, gender);
    this.active = true;
    this.id = autoincrement++;
  }


  public int getId(){
    return this.id;
  }
  public boolean isActive(){
    return this.active;
  }
  public void setActive(boolean active){
    this.active = active;
  }

  @Override
  public String toString(){

    return String.format("%-5d %-73s", this.id, super.toString());
  }
}
