
import enigma.core.Enigma;
import enigma.console.Console;
import enigma.console.TextAttributes;
import java.awt.Color;



public class UserInterface{

  public Console console;
  private final TextAttributes defaultColor;
  private final TextAttributes errorColor;
  private final TextAttributes successColor;
  private final TextAttributes headerColor;
  private final TextAttributes tableColor;
  private final TextAttributes deletedRecordColor;


  public UserInterface(String name, int width, int height, int fontSize){

    this.console = Enigma.getConsole(name, width, height, fontSize, 0);
    this.defaultColor = new TextAttributes(new Color(230,230,230)); // WHITE
    this.errorColor = new TextAttributes(new Color(255,51,51)); //RED
    this.successColor = new TextAttributes(new Color(9,199,69)); //GREEN
    this.headerColor = new TextAttributes(new Color(157,169,182)); //GRAY
    this.tableColor = new TextAttributes(new Color(230,230,230), new Color(50,50,50));
    this.deletedRecordColor = new TextAttributes(new Color(230,230,230), new Color(114,37,37));
  }

  public void printError(String message){

    console.setTextAttributes(errorColor);
    System.out.println(" " + message);
    console.setTextAttributes(defaultColor);
    if(!Management.isStreaming)
      System.out.print("> ");
  }

  public void printSuccess(String message){

    console.setTextAttributes(successColor);
    System.out.println(" " + message);
    console.setTextAttributes(defaultColor);
    if(!Management.isStreaming)
      System.out.print("> ");

  }

  public void print(String message, int indicator){

    if(indicator % 2 == 0){

      System.out.println(" " + message);
      if(!Management.isStreaming)
        System.out.print("> ");
    }
    else{

      console.setTextAttributes(tableColor);
      System.out.println(" " + message);
      if(!Management.isStreaming)
        System.out.print("> ");
      console.setTextAttributes(defaultColor);
    }
  }

  public void print(String message){

    System.out.println(" " + message);
    if(!Management.isStreaming)
      System.out.print("> ");

  }

  public void printDeletedRecord(String message){

    console.setTextAttributes(deletedRecordColor);
    System.out.println(" " + message);
    if(!Management.isStreaming)
      System.out.print("> ");
    console.setTextAttributes(defaultColor);
  }

  public void printHeader(String message){

    console.setTextAttributes(headerColor);
    System.out.println("\n" + message + "\n");
    console.setTextAttributes(defaultColor);
  }

  public void append(String message, int red, int green, int blue){

    console.setTextAttributes(new TextAttributes(new Color(red,green,blue)));
    System.out.print(message);
    console.setTextAttributes(defaultColor);
  }

  public String getInput(){

    return console.readLine();
  }

  public void clear(){

    for(int i = 0; i < console.getTextWindow().getRows(); i++)
      System.out.print("\n");

    console.getTextWindow().setCursorPosition(0, 0);
    System.out.print("> ");
  }
}
